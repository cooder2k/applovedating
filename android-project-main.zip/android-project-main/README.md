<img src="screen/Love Dating Logo.png" ></img> 
<br/>
# DatingApp
Android app like Tinder.
<br/>

<img src="screen/screen1.png" ></img> <br/>
<img src="screen/screen2.png" ></img> <br/>
<img src="screen/screen3.png" ></img> <br/>
<img src="screen/screen4.png" ></img> <br/>

## Download

* [LoveDating](https://github.com/quintuslabs/DatingApp/blob/master/lovedating1.2.apk) - Download APK
<br/>

<br/>
Dating UI kit is used for online meet up with girls and boys . The screen contains more than 30 icons and most of all required elements required to design an application like this.
The XML and JAVA files contains comments at each and every point for easy understanding.
Everything was made with a detail oriented style and followed by today's web trends. Clean coded & Layers are well-organized, carefully named, and grouped.
Change text, colours and graphics, add or place photos.
Customize every elements as much, or as little as you want.
Customise elements (easy to edit)
100% free fonts
Perfect pixel (high quality design)
Very clean and cool UI
Free updates

This awesome multipurpose dating app designed with a strong sense of modern and new UI, UX concepts. The application has been created with Ansdroid Studio. This awesome template app is highly customizable, user and developer friendly which holds high code quality, reflects module based project structure and many more.

By using this template UI app save your 1000% development time. This app presents a lot of layouts (Slider Landing Page, Sign In Page, Multiple Slider Sign Up Page, Swipe Page, Match Page, Gorgeous Chat Page with Giphy Support, User Public Profile, User Own Profile, Edit Profile Page and Settings pages) etc. 

Therefore, this well-organized design concepts template app will help to build your dating app exactly what you’re looking for.

